# fcc_cat_dog_project
#### freeCodeCamp Cat and Dog Image Classifier Project

TensorFlow 2.0 and Keras were used to create a convolutional neural network that correctly classifies images of cats and dogs with at least 63% accuracy.

Challenge was achieved by creating a model which is correctly identified 72.0% of the images of cats and dogs.
